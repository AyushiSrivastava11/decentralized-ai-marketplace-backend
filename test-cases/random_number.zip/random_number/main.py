import json
import os
import random

def main():
    input_json = os.getenv("INPUT_JSON", "{}")
    data = json.loads(input_json)

    min_val = data.get("min", 0)
    max_val = data.get("max", 100)

    rand_num = random.randint(min_val, max_val)

    print(json.dumps({"random_number": rand_num}))

if __name__ == "__main__":
    main()
