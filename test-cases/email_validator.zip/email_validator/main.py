import json
import os
import re

def main():
    input_json = os.getenv("INPUT_JSON", "{}")
    data = json.loads(input_json)

    email = data.get("email", "")
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    is_valid = bool(re.match(pattern, email))

    print(json.dumps({"is_valid": is_valid}))

if __name__ == "__main__":
    main()
