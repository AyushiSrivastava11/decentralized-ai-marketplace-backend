import json
import os

def main():
    input_json = os.getenv("INPUT_JSON", "{}")
    data = json.loads(input_json)

    text = data.get("text", "").lower()
    if "good" in text:
        sentiment = "positive"
    elif "bad" in text:
        sentiment = "negative"
    else:
        sentiment = "neutral"

    print(json.dumps({"sentiment": sentiment}))

if __name__ == "__main__":
    main()
