import json
import os

def main():
    input_json = os.getenv("INPUT_JSON", "{}")
    data = json.loads(input_json)

    input_text = data.get("text", "")
    word_count = len(input_text.split())

    result = {"word_count": word_count}

    print(json.dumps(result))

if __name__ == "__main__":
    main()
