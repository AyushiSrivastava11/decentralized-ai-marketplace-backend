import json
import os

def main():
    input_json = os.getenv("INPUT_JSON", "{}")
    data = json.loads(input_json)

    a = data.get("a", 0)
    b = data.get("b", 0)
    result = a * b

    print(json.dumps({"result": result}))

if __name__ == "__main__":
    main()
